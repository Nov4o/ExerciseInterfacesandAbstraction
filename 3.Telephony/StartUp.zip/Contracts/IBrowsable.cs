﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _3.Telephony.Contracts
{
    public interface IBrowsable
    {
        public void Browse(string URL_Link);

    }
}
